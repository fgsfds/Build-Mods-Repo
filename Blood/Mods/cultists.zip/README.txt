Installation:

====NBlood / BuildGDX====

1. Drop drop file Cultists.zip into your "autoload" directory.
2. Make sure the autoload option in the launcher is checked.

====Raze====

Drag and drop file Cultists.zip onto Raze.exe and select Blood as game.

Alternatively you may set either an absolute or relative path in raze_portable.ini to Cultists.zip located e.g. in "autoload" folder, like this

Absolute path:

   [Blood.Autoload]
   Path=C:\Games\Raze\autoload\Cultists.zip

Relative path:

   [Blood.Autoload]
   Path=autoload\Cultists.zip



Special thanks to phredreeke for fixing my problems with culitsts' palette and fgsfds for making a nice Tommy gun voxel which was the reference for Fanatic's gun.
And CL102 for fixing the issue where custom seqs didn't work for custom maps.