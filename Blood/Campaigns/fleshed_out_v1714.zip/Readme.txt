
Hello everyone, 

Welcome to the latest version of Blood: Fleshed Out Version 1.7
Thank you all for downloading 
Just a few things:

Installation for Blood: Fresh Supply:

1.Copy "Fleshed Out v1.7" folder to:

Steam > steamapps > common > Blood > addons >

2. Paste the "Fleshed out v1.7" folder into the "addons" folder   
    
3. Open Fresh Supply and go to Main menu > Options > manage       addons, it should show "Fleshed out"

4. select the Add-on and then > 

"Through the Veins"
"Rotten Tales"
"Praying with Fire"

Please note: 

Fleshed Out have mostly been play tested on BuildGDX and Fresh Supply, and should work best on these versions.

*DOSBOX causes too much performance issues and will crash

Get BuildGDX:

http://m210.duke4.net/

Special Thanks: 

http://blood.freeminded.de/
http://www.baitd.bloodgame.ru/bme.htm#tutorials

Could not have made Fleshed Out without these tutorials, it sped up the development time and made stuff easy to understand.

The Blood communtiy: 

Those who made mods/maps/art/music/content to keep the game alive over the years, a lot was learned by playing fan-made projects.

Some very gifted individuals, thank you all for your outstanding work and keep on creating please. 

Youtube:

Pagb666
Ceekur

For taking the time to play through all the levels, 
a lot of changes have been made since to make it more fun.

You:

To every single person that have taken the time to comment, make a review, suggestion, message, input, criticism, and sharing 

Every single suggestion have been taken into account to make this a better add-on overall. 

Thanks for your help

- Skobbejak Games   



 




 




 