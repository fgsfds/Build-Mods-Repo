=============================================================
FRENCH MEAT v2.2
02/12/2019
=============================================================
THIS ADDON CONTAINS:

.FRENCH MEAT 2 :
- This is an new episode of 8 maps created between 2013 and 2019.
- Singleplayer only.

.FRENCH MEAT 1 included in updated edition :
- This is the first episode of 9 maps created between 2008 and 2012.
- Singleplayer and two players in cooperative.
============================================================
- Mapped by TEDD
- Tested and approved by Le Babe (INFUSCOMUS)
- Help and Scripting by BME
============================================================

FOR DOS USERS

-> Unzip contents (FRENCHM2.BAT file and FRENCHM2 folder) to Blood folder
-> Drag FRENCHM2.BAT unto the DOSBox icon to run

<<< WARNING >>>
**************************************************************************
* Make sure you NEVER close DOSBox while still in the game or the script *
* is not able to restore the files! ALWAYS quit from the game's menu.    *
********************************************************************<BME>*

============================================================

FOR WINDOWS 95 / 98 AND DOS COMPATIBLE USERS

-> Unzip all the maps + FRENCHM2.ini in your blood folder.
-> Create a shortcut from your blood.exe
-> Right clic on your new blood shortcut and go to properties
-> At the end of the command line of the shortcut, write :
   -ini FRENCHM2.ini (don't forget to put a space between the already
   existing text and that line)
-> Apply / save
-> Just use the shortcut, it should launch blood with the add on.

============================================================

FOR DOS BOX USERS

(Without config file)

-> Unzip all the maps + FRENCHM2.ini in your blood folder.
-> Open dosbox
-> Mount your c: as your blood folder 
   (mount c [path to your blood folder] - ex : mount c c:\Games\BLOOD)
-> Type "c:"
-> type "blood -ini FRENCHM2.ini"
-> This should lauch Blood with the add on

(With config file)

-> Unzip all the maps + FRENCHM2.ini in your blood folder.
-> Just use the frenchmeat config file (put it in your DOSBOX folder)
   you can find in the zip or create a config file for the add on if
   you are used to it.
-> Open the config file and go to the bottom of it in the [Autoexec] part
-> If you use the frenchmeat conf file, modify the path to you
   blood folder in the "mount c c:\Jeux\BLOOD" line
-> If you use your custom conf file... you probably know all that stuff anyway...
-> Create a shortcut from your dosbox.exe
-> Right clic on the new shortcut and modify the end of its command line|
   so that it says "blabla" -conf frenchmeat.conf (don't forget the spaces)
-> Apply / save
-> Just use this shortcut to launch the add on.

============================================================
Please report any performance issues, likes, dislikes and 
any problems on "the postmortem" forum (or you can email me 
directly at: teddyleger@gmail.com
============================================================

THANKS : The Blood community in general and the-postmortem forums in particular,
because I wouldn't have had the motivation to make this add on if such a thing
didn't exist.
Keep playing Blood and enjoy it, spread the love of that game and keep the flame
burning. Special thanks to Daedalus for his help with some mapedit questions
and other I forgot. 

Crudux Cruo ! Kill everyone !

TEDD
