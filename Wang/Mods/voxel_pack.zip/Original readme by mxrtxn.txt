
		SHADOW WARRIOR VOXEL PACK


Updated May 22th 2021 by mxrtxn



This voxel pack is constantly being updated at (download link will be updated there):

http://swforum05.proboards.com/thread/45/shadow-warrior-voxel-pack

			

			CREDITS


Several voxels were made by the team behind the shadow warrior addons: When I Was Young, TNE, The last warrior, Park. (I never knew who exactly made the voxels as they worked as a team)

Some of them have no use except to their correspondent addons so I didn�t include then in this voxel pack. Although they are included in the pack called "The missing voxels".

The on-off light switch voxels were adapted from ReaperMan�s Duke Nukem voxel pack. Also the faucet I took it from ReaperMan�s Voxel Pack. It will be replaced eventually.

the  tcastsw voxel was adapted from Blood Voxel Pack (originally named tcast). I couldn�t find the author. If you know who he or she is let me know to include him/her in the credits.

The woodn2 voxel (the wooden punching staff) was made by Kada Lewobski.


The voxels that were made by me from scratch are:

tea cup
coffee cup
rice cup (the one with chopsticks)
bottle (the one that looks like a wine bottle)
soap dispenser
dryer
sake bottle (found in shaghai shipwreck and 1st level wanton destruction)
candle voxels (seems it�s not possible to make them animated)
blue cup
Toilet paper
Shower
whanger (found in bath house and inside the submarine)
smallcast
graybottle
blackbox
blackcup
bluestuff

Other voxels mentioned with the update date:

and also all the new voxels of the updates (2014, 2015)

Modified by me

parasol
stonelamp
stonelampfire (modified from the stonelamp voxel)
bluestonelamp  (fixed the blue stain)
tcastsw (modified form Blood�s Voxel Pack)
light switches and faucet (from ReaperMan)

Other voxels made by me:

Previous update: Update 4th nov (2014)

helmet
barrel
barrel2
blackr
silv
paper
trash
handle
tcan (not included)
ebuttn (voxelized switch)
ebuttn2
pike
pike2 
pike3
pike4
pike5
staff1

Update 20th May (2015)

220
phone
treea
treec
pencil
condon
tcan2 (provisory)
mizu

Update 09 Feb (2016)

lockkk (found in 3 unlockable doors in Seppuku station)
fixed pivots in the 3 candle animations (candle1, candle2, candle3)

With Hendricks�s SWP newest patch now you can see them animated

Update 27 July (2016)

chair2
chair3
woodn2 (This one was made by Kada Lebowski)

Update 26 August (2018):

litbox
case1
case2
shower (modified the corners)
bbag
sword1
katanas
travel1
travel2
barrelw
ratfood
ratfood2
flagb
axes
woodn3
woodn4
bathw

Special Update (Jun 2019) First Enemy Voxel Corpse

flagb
coolied (special enemy voxel)
bskull
wet
mopsw2 (modified from blood voxel pack and to be replaced by a more faithful voxel in the future)

Special Update (Aug 1019)

claydr (the sort of clay vase in Zilla�s villa)
soap (it doesn�t include the bubles of the original sprite)
gsit (the green plastic seat in Bath house)
flagyb (the blue and white ying yang banner)
wlamp
rphone1*
rphone2*
phonenew1*
phoneb*


*The phone sprites weren�t used as such in the game therefore either the voxel won�t appear or only a part appear like in the train level of Wanton Destruction. I still decided to include them as they could be of interest to modders and fans.

Retouched the coolie and the bskull voxels

UPDATE 24 March 2020

mswitch1
mswitch2 (these are the metal switches in the crude oil level)
lpole1
lpole2 (the light stand next to the turret in Level 1 Seppuku Station)
snakeb (the serpent god corpse, still in early alpha as it needs lots of retouches and fixes)
court  (the courtains of the first level in Wanton Destruction also present in the rooms of the skyscrapper level)
scissor (the scissors in the hospital and other level of the Twin Dragon expansion)
drkit (the doctor�s briefcase in the hospital level of the Twin Dragon expansion)
stbuttna
stbuttnb (the stone buttons with red light found in the airport level and in other levels)
plampry2
plampy
plampb 
paperln
redlamp
biglamp (this six voxels are the paper and other asian lamps found in the game for instance in level 1, in the bath house level, etc. Also present in the expansions)

* the parasol voxel was retouched in this update.

UPDATE 8TH August 2020

fsphere
fshhere2 (those are the glass sphere found in the bath level and the sumo boss level, one is closer to the original sprite)
vasewht4
vasebrw2 (these are the potted plants the 2 remaining will be made in the future, these will be also retouched in future updates)
lighty
lighty2 (the lightbulbs attached to walls and ceiling in several levels)
towelb
towel (the towels of the bath house had to make two version for future map hacks)
mclight
mclight2
mclight3
mclight4
fireworks
tnt
barrel2
manga3
chain0 (disabled due that in the airport map looks bad )
nclight
mlight

Extra voxels to replace the 0502 sprite:

hadaka magazines voxels, gameboy voxels, Miho Nomoto pentouse voxels (that is the japanese model of one of the original spirtes) 

-redlamp voxel retouched
-stbuttnb and stbuttna voxels disabled due to problem in the airport level.
-serpent god corpse disabled
-alpha ninja corpse disabled

UPDATE 24 OCTOBER 2020 (New voxelized enemy corpse: dcgirlx, dcgirl0)

-Animated voxels are better shown in BUILD GDX
-Retouched the potted plants
-Modified the oil barrels, though I included the original voxels in the pack if you wanna change them.
-New voxelized enemy corpse

parasol2 (the damaged parasol)
dcgirl0 (the corpse of the female enemy that uses a crossbow)
dcgirlx (the same but exposing her breasts)
mizu0, mizu1, mizu2, mizu3 (the wooden container with water, the four frames for the animated voxels)
mdish1
mdish2 (those two are the metal dishes with food in secret level "Auto Maul")
gasbot2 (the gas container, the other less frequent version)
hlight, hlight2, hlight3, hlight4 (the animated sequence of the hanging light in the Dojo of Lo Wang, 1st Level Seppuku Station)

SPECIAL UPDATE 22th MAY 2021  (Experimental Ninja voxels):

nin4104
nin4105
nin4106
nin4107
nin4116
nin4117
nin4226
rock695 (stone in Lo Wang�s House)
rock696 (stone in Lo Wang�s House)
cash4886 (the little cash screen in the cashier�s machine)

Also the black trash bin was remade!

0705 the orange trash bin found in secret level 22 (made by another voxel maker, Dzierzan)



EXTRA CONTENT: Voxel cameras to replace the 0068 sprite (cam, cam2)

http://oi57.tinypic.com/t0p3iq.jpg

ACTIVATING EXTRA VOXELS:

To replace the 0068 sprite just go to the voxfil.txt file and modify it. By default I put the cam2.kvx voxel there. To get the original sprite just modify or erase the name of the voxel.




			FAQ

What if I want to disable a particular voxel?

Let�s say I don�t like the stonelamp voxel and I just want to disable that voxel and keeping the rest intact.

I just go to the SWVOXFIL.txt file and search for the voxel and the sprite it replaces, in this case is:

0442 80 stonelamp.kvx 

to disable just add any letter to the voxel name if I write, for instance 

0442 80 stonelampz.kvx

the program won�t recognize it as the voxel name changed so the original sprite won�t be replaced by the voxel, thus keeping the original sprite intact.

Easy right? :)

Have fun and let me know your thoughts

Martin (mxrtxn)




