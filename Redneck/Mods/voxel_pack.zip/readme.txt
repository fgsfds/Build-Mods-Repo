======================================================
Voxel key for Redneck Rampage
======================================================

Version:       1.0
Release Date:  05.08.2021


======================================================
ABOUT
======================================================

Voxel replacement for keys.
It is meant to be used with BuildGDX, Rednukem or Raze port.

======================================================
HOW TO USE
======================================================

BuildGDX (1.13 or later) and Rednukem:
- put voxel-key.zip into autoload folder in your Redneck Rampage folder
- make sure "enable autoload folder" checkbox is enabled

Raze:
- drag and drop voxel-key.zip onto Raze.exe

Or add these lines in your raze-username.ini file:

[Redneck.Autoload]
Path="path to this addon"/voxel-key.zip

======================================================
LINKS
======================================================

> BuildGDX port:
   https://m210.duke4.net/index.php/downloads/download/8-java/53-buildgdx

> Rednukem dev builds:
   https://lerppu.net/wannabethesis/

> Raze port:
   https://github.com/coelckers/Raze/releases


======================================================
CREDITS
======================================================

> Voxel:
    fgsfds (https://twitter.com/fgsfds228)

> Based on the work by
   Xatrix Entertainment
