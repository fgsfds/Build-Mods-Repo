![](https://imgur.com/z6NI021.png)

# About

This repository contains custom voxels created for Ion Fury game developed by Voidpoint, published by 3D Realms.

# How to use it

Clone the project or download the zip and put all the content in Ion Fury directory.
If you don't have the Aftershock DLC, you can get rid of (most of) the missing *.kvx error logfile messages by commenting out loading the dlc_voxels in "voxels.def".

# Voxel artists

1. fgsfds (https://twitter.com/fgsfds228)
2. Dzierzan (https://twitter.com/Dzierzan23)