==========================================================================
Duke Nukem 3D Nude Patch
==========================================================================

Version:         0.91
Release Date:    03.05.2020
Author:          fgsfds (https://twitter.com/fgsfds228)


==========================================================================
ABOUT
==========================================================================

  This pack provides an art replacement that partially or fully removes
clothes from female NPCs and posters in OG Duke 3D and its addons.


==========================================================================
HOW TO USE
==========================================================================

BuildGDX (1.04 and later) and EDuke32:
- put dukexxx.zip into autoload folder
- make sure "enable autoload folder" checkbox is enabled


==========================================================================
CREDITS
==========================================================================

fgsfds
Pigeon — Duke Nukem XXX
Dan Reames (the Mechanic) — Duke Nudes X


==========================================================================
LINKS
==========================================================================

> BuildGDX port:
  https://m210.duke4.net/

> EDuke32 port:
  https://www.eduke32.com/


==========================================================================
CHANGELOG
==========================================================================

Version 0.91 (03.05.2020)
---------------------------
+ World Tour Sprites (5753, 5755, 5758)

Version 0.9 (13.09.2019)
---------------------------
> Initial release